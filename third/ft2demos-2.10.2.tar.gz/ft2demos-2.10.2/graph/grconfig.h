#ifndef GRCONFIG_H_
#define GRCONFIG_H_

#define GR_MAX_SATURATIONS  8
#define GR_MAX_CONVERSIONS  16

#endif /* GRCONFIG_H_ */
