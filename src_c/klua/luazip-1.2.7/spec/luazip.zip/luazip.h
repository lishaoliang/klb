
#ifndef lzip_h
#define lzip_h

#include "lua.h"

#ifndef LZIP_API
#define LZIP_API	LUA_API
#endif

#define LUA_ZIPLIBNAME	"zip"
LZIP_API int luaopen_zip (lua_State *L);

#endif
